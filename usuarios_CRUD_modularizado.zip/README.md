# Core de Flask con SQL modularizado

Core flask + SQL.