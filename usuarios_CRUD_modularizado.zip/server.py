from usuarios_app import app
from usuarios_app.controladores import controlador_usuarios

if __name__ == "__main__":
    app.run( debug = True )